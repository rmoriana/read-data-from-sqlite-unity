﻿using SQLite4Unity3d;

public class Enemy  {

	public string Type { get; set; }
	public int Vida { get; set; }

	public override string ToString ()
	{
		return string.Format ("[Enemy: Type={0}, Vida={1}  ]", Type, Vida);
	}
}