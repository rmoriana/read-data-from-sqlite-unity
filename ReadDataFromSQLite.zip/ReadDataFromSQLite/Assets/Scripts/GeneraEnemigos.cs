﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

public class GeneraEnemigos : MonoBehaviour {

	public Text DebugText;
	int i;
	float posX;
	float posY;
	List <GameObject>enemyList = new List<GameObject>();
	string[] typeArray = { "Verde", "Azul", "Rojo" }; 
	DataService ds;
    public GameObject player;

	//Start database connection
	void Start () {
		ds = new DataService("examenEnemies.bd.db");
	}
		
	void Update () {

        //Spawn enemies based on database data when there are less than 15 enemies on screen.
		while (enemyList.Count < 15) {

			int color = Random.Range (0, 3);
			IEnumerable enemy =  ds.GetEnemies (typeArray[0]);
			//string tipo = "azul";

			var enemyType = ds.GetEnemies (typeArray[color]);

			foreach (Enemy enemies in enemyType) {

				posX = Random.Range (-10f, 10f);
				posY = Random.Range (-5f, 5f);
				GameObject enemyCreated = Instantiate (Resources.Load (enemies.Type), new Vector2 (posX, posY), new Quaternion (0, 0, 0, 0)) as GameObject;				
				enemyList.Add (enemyCreated);
			}			
		}

        //Destroy enemies which are near the player.
		for (i = 0; i < enemyList.Count; i++) {

			calculaMovimiento (enemyList[i]);

			if (enemyList[i].transform.position.y < 0.2f && enemyList[i].transform.position.y > -0.2f && enemyList[i].transform.position.x < 0.2f && enemyList[i].transform.position.x > -0.2f) {
				Destroy (enemyList [i]);
				enemyList.RemoveAt (i);			
			}

		}

	}

    //Move enemies close to the player.
	private void calculaMovimiento(GameObject enemy){

        enemy.transform.position = Vector2.MoveTowards(enemy.transform.position, player.transform.position, 0.03f);
	
	}

	private void ToConsole(IEnumerable<Enemy> enemy){
		foreach (Enemy enemies in enemy) {
			ToConsole(enemies.ToString());
		}
	}

	private void ToConsole(string msg){
		DebugText.text += System.Environment.NewLine + msg;
		Debug.Log (msg);
	}
		
}
